def my_sum(arr): 
    return int(sum(list(map(int,(arr.split(" "))))))
