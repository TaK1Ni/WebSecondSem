
def sum_and_sub(a,b):
    return f"{a+b} {a-b}"

print(sum_and_sub(2,1))